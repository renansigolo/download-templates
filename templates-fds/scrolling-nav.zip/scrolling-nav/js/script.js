/* Insira seu código em javascript abaixo */

console.log('Olá Mastertech!');
